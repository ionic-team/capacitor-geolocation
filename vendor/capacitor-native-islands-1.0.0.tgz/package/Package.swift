// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "CapacitorNativeIslands",
    platforms: [.iOS(.v16)],
    products: [
        .library(
            name: "CapacitorNativeIslands",
            targets: ["NativeIslandsPlugin"])
    ],
    dependencies: [
        .package(url: "https://github.com/ionic-team/capacitor.git", from: "9.0.0-beta.0"),
        // Intentional local override until the native library has an immutable release.
        // Dependency closure replaces this with
        // .package(url: "https://github.com/ionic-team/ion-ios-native-islands.git", from: "1.0.0")
        // before any package is published.
        .package(path: "../ion-ios-native-islands")
    ],
    targets: [
        .target(
            name: "NativeIslandsPlugin",
            dependencies: [
                .product(name: "Capacitor", package: "capacitor"),
                .product(name: "IONNativeIslandsLib", package: "ion-ios-native-islands")
            ],
            path: "ios/Sources/NativeIslandsPlugin")
    ]
)
