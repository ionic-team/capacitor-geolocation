import Capacitor
import CoreFoundation
import IONNativeIslandsLib
import UIKit
import WebKit

/// Capacitor marshalling shell for the shared Native Islands controller.
@objc(NativeIslandsPlugin)
public class NativeIslandsPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "NativeIslandsPlugin"
    public let jsName = "NativeIslands"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "applyLayout", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "command", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "reset", returnType: CAPPluginReturnPromise)
    ]

    private lazy var controller = NativeIslandsController(
        events: { [weak self] event, payload in
            self?.notifyListeners(event, data: payload)
        }
    )

    private lazy var directChannel = NativeIslandsDirectChannel(plugin: self)

    override public func load() {
        controller.ensureContainer(webView: webView)
        webView?.configuration.userContentController.addScriptMessageHandler(
            directChannel,
            contentWorld: .page,
            name: NativeIslandsDirectChannel.name(jsName)
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(hostDidResume),
            name: UIApplication.didBecomeActiveNotification,
            object: nil
        )
        if UIApplication.shared.applicationState == .active {
            controller.onHostResume()
        } else {
            controller.onHostPause()
        }
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(hostDidPause),
            name: UIApplication.willResignActiveNotification,
            object: nil
        )
    }

    deinit {
        webView?.configuration.userContentController.removeScriptMessageHandler(
            forName: NativeIslandsDirectChannel.name(jsName),
            contentWorld: .page
        )
        NotificationCenter.default.removeObserver(self)
        controller.dispose()
    }

    @objc func applyLayout(_ call: CAPPluginCall) {
        guard let payload = call.options as? [String: Any] else {
            call.reject("operation payload must be an object", "invalid_request")
            return
        }
        applyLayout(payload, resolve: { call.resolve($0) }, reject: { code, message in call.reject(message, code) })
    }

    func applyLayout(
        _ payload: [String: Any],
        resolve: @escaping ([String: Any]) -> Void,
        reject: @escaping (_ code: String, _ message: String) -> Void
    ) {
        if let failure = controller.validateLayoutOperation(payload) {
            let code = failure["code"] as? String ?? "invalid_request"
            reject(code, failure["error"] as? String ?? code)
            return
        }
        guard
            let components = payload["components"] as? [[String: Any]],
            let scrollContainers = payload["scrollContainers"] as? [[String: Any]],
            let order = payload["order"] as? [String],
            let exclusions = payload["exclusions"] as? [String: Any],
            let cutouts = payload["cutouts"] as? [String: Any],
            let tints = payload["tints"] == nil ? [:] : payload["tints"] as? [String: Any]
        else {
            reject(
                "invalid_request",
                "layout envelope must contain component, scroll container, order, exclusion, and cutout fields"
            )
            return
        }
        if let reason = controller.validateLayout(
            components: components,
            scrollContainers: scrollContainers,
            order: order,
            exclusions: exclusions,
            cutouts: cutouts,
            tints: tints,
            canvasColor: payload["canvasColor"],
            panes: payload["panes"],
            motions: payload["motions"],
            sentAt: payload["sentAt"],
            fence: payload["fence"]
        ) {
            reject("invalid_request", reason)
            return
        }
        controller.applyLayout(
            components: components,
            scrollContainers: scrollContainers,
            order: order,
            exclusions: exclusions,
            cutouts: cutouts,
            tints: tints,
            canvasColor: payload["canvasColor"] as? String,
            panes: payload["panes"],
            motions: payload["motions"],
            sentAt: (payload["sentAt"] as? NSNumber)?.doubleValue,
            fence: (payload["fence"] as? NSNumber)?.intValue,
            failure: reject,
            completion: { appliedAt in
                resolve(appliedAt.map { ["appliedAt": $0] } ?? [:])
            }
        )
    }

    @objc func command(_ call: CAPPluginCall) {
        guard let payload = call.options as? [String: Any] else {
            call.reject("operation payload must be an object", "invalid_request")
            return
        }
        command(payload, resolve: { _ in call.resolve() }, reject: { code, message in call.reject(message, code) })
    }

    func command(
        _ payload: [String: Any],
        resolve: @escaping ([String: Any]) -> Void,
        reject: @escaping (_ code: String, _ message: String) -> Void
    ) {
        if let failure = controller.validateOperation("command", payload: payload) {
            let code = failure["code"] as? String ?? "invalid_request"
            reject(code, failure["error"] as? String ?? code)
            return
        }
        guard
            let island = payload["island"] as? String,
            let component = payload["islandType"] as? String,
            let method = payload["method"] as? String
        else {
            reject("invalid_request", "command envelope is incomplete")
            return
        }
        let params: [String: Any]
        if let rawParams = payload["params"] {
            guard let object = rawParams as? [String: Any] else {
                reject("invalid_request", "command params must be an object")
                return
            }
            params = object
        } else {
            params = [:]
        }
        controller.dispatchCommand(
            island: island,
            requestedType: component,
            method: method,
            params: params,
            instance: payload["instance"]
        ) { result in
            if let code = result["code"] as? String {
                reject(code, result["error"] as? String ?? code)
            } else {
                resolve([:])
            }
        }
    }

    @objc func reset(_ call: CAPPluginCall) {
        guard validateOperation(call, operation: "reset") != nil else {
            return
        }
        controller.reset {
            call.resolve(NativeIslandsController.sessionCapabilities)
        }
    }

    @objc private func hostDidResume() {
        controller.onHostResume()
    }

    @objc private func hostDidPause() {
        controller.onHostPause()
    }

    private func validateOperation(
        _ call: CAPPluginCall,
        operation: String,
        layout: Bool = false
    ) -> [String: Any]? {
        guard let payload = call.options as? [String: Any] else {
            call.reject("operation payload must be an object", "invalid_request")
            return nil
        }
        let failure = layout
            ? controller.validateLayoutOperation(payload)
            : controller.validateOperation(operation, payload: payload)
        if let failure {
            let code = failure["code"] as? String ?? "invalid_request"
            call.reject(failure["error"] as? String ?? code, code)
            return nil
        }
        return payload
    }
}
