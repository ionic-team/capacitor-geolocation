import Capacitor
import IONNativeIslandsLib
import UIKit
import WebKit

/// Capacitor carrier for the shared Native Islands controller.
@objc(NativeIslandsPlugin)
public class NativeIslandsPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "NativeIslandsPlugin"
    public let jsName = "NativeIslands"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "applyLayout", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "command", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "reset", returnType: CAPPluginReturnPromise)
    ]

    private lazy var controller = NativeIslandsController(
        events: { [weak self] event, payload in
            self?.notifyListeners(event, data: payload)
        }
    )

    private lazy var directChannel = NativeIslandsDirectChannel(controller: controller)

    override public func load() {
        controller.ensureContainer(webView: webView)
        webView?.configuration.userContentController.addScriptMessageHandler(
            directChannel,
            contentWorld: .page,
            name: NativeIslandsDirectChannel.name(jsName)
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(hostDidResume),
            name: UIApplication.didBecomeActiveNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(hostDidPause),
            name: UIApplication.willResignActiveNotification,
            object: nil
        )
        if UIApplication.shared.applicationState == .active {
            controller.onHostResume()
        } else {
            controller.onHostPause()
        }
    }

    deinit {
        // WebKit's content controller is main-thread only; a plugin can be released on another thread.
        let contentController = webView?.configuration.userContentController
        let name = NativeIslandsDirectChannel.name(jsName)
        let removeHandler: () -> Void = {
            contentController?.removeScriptMessageHandler(forName: name, contentWorld: .page)
        }
        if Thread.isMainThread {
            removeHandler()
        } else {
            DispatchQueue.main.async(execute: removeHandler)
        }
        NotificationCenter.default.removeObserver(self)
        controller.dispose()
    }

    @objc func applyLayout(_ call: CAPPluginCall) {
        controller.applyLayout(call.options, failure: rejection(of: call)) { call.resolve($0) }
    }

    @objc func command(_ call: CAPPluginCall) {
        controller.command(call.options, failure: rejection(of: call)) { call.resolve() }
    }

    @objc func reset(_ call: CAPPluginCall) {
        controller.reset(call.options, failure: rejection(of: call)) { call.resolve($0) }
    }

    @objc private func hostDidResume() {
        controller.onHostResume()
    }

    @objc private func hostDidPause() {
        controller.onHostPause()
    }

    private func rejection(of call: CAPPluginCall) -> (_ code: String, _ message: String) -> Void {
        { code, message in call.reject(message, code) }
    }
}
