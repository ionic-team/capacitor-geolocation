import Foundation
import WebKit

final class NativeIslandsDirectChannel: NSObject, WKScriptMessageHandlerWithReply {
    private weak var plugin: NativeIslandsPlugin?

    init(plugin: NativeIslandsPlugin) {
        self.plugin = plugin
    }

    static func name(_ jsName: String) -> String {
        "ni.\(jsName)"
    }

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage,
        replyHandler: @escaping (Any?, String?) -> Void
    ) {
        let reject = { (code: String, text: String) in
            replyHandler(nil, Self.error(code: code, message: text))
        }
        guard
            message.frameInfo.isMainFrame,
            let text = message.body as? String,
            let object = try? JSONSerialization.jsonObject(with: Data(text.utf8)) as? [String: Any],
            let operation = object["operation"] as? String,
            let payload = object["payload"] as? [String: Any]
        else {
            reject("invalid_request", "operation payload must be an object")
            return
        }
        guard let plugin else {
            reject("internal_error", "Native Islands is not loaded.")
            return
        }
        let resolve = { (result: [String: Any]) in replyHandler(result, nil) }
        switch operation {
        case "applyLayout":
            plugin.applyLayout(payload, resolve: resolve, reject: reject)
        case "command":
            plugin.command(payload, resolve: resolve, reject: reject)
        default:
            reject("invalid_request", "unknown operation")
        }
    }

    private static func error(code: String, message: String) -> String {
        let data = try? JSONSerialization.data(withJSONObject: ["code": code, "message": message])
        return data.flatMap { String(data: $0, encoding: .utf8) } ?? message
    }
}
