import Foundation
import IONNativeIslandsLib
import WebKit

/// Takes layouts and commands from the page's `ni.<plugin name>` WebKit handler on the main thread,
/// without waiting in the Capacitor bridge queue.
final class NativeIslandsDirectChannel: NSObject, WKScriptMessageHandlerWithReply {
    private weak var controller: NativeIslandsController?

    init(controller: NativeIslandsController) {
        self.controller = controller
    }

    static func name(_ jsName: String) -> String {
        "ni.\(jsName)"
    }

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage,
        replyHandler: @escaping (Any?, String?) -> Void
    ) {
        let reject = { (code: String, text: String) in
            replyHandler(nil, Self.error(code: code, message: text))
        }
        guard
            message.frameInfo.isMainFrame,
            let text = message.body as? String,
            let object = try? JSONSerialization.jsonObject(with: Data(text.utf8)) as? [String: Any],
            let operation = object["operation"] as? String,
            let payload = object["payload"] as? [String: Any]
        else {
            reject("invalid_request", "operation payload must be an object")
            return
        }
        guard let controller else {
            reject("internal_error", "Native Islands is not loaded.")
            return
        }
        switch operation {
        case "applyLayout":
            controller.applyLayout(payload, failure: reject) { replyHandler($0, nil) }
        case "command":
            controller.command(payload, failure: reject) { replyHandler([String: Any](), nil) }
        default:
            reject("invalid_request", "unknown operation")
        }
    }

    private static func error(code: String, message: String) -> String {
        let data = try? JSONSerialization.data(withJSONObject: ["code": code, "message": message])
        return data.flatMap { String(data: $0, encoding: .utf8) } ?? message
    }
}
