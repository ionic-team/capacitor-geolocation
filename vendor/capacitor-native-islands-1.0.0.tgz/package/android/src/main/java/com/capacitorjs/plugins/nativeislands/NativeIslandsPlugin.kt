package com.capacitorjs.plugins.nativeislands

import androidx.lifecycle.Lifecycle
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import io.ionic.libs.ionnativeislandslib.NativeIslandsController
import io.ionic.libs.ionnativeislandslib.NativeIslandsScrollChannel

/** Capacitor carrier for the shared Native Islands controller. */
@CapacitorPlugin(name = "NativeIslands")
class NativeIslandsPlugin : Plugin() {

    private val controller by lazy {
        NativeIslandsController { event, payload ->
            notifyListeners(event, JSObject.fromJSONObject(payload))
        }
    }

    override fun load() {
        controller.bind(bridge.webView, activity)
        activity.runOnUiThread {
            NativeIslandsScrollChannel.install(
                bridge.webView,
                "NativeIslands",
                bridge.allowedOriginRules,
                controller::receiveScrollOffsets,
                controller::receiveDirect,
            )
            controller.ensureContainer()
            if (activity.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                controller.onHostResume()
            } else {
                controller.onHostPause()
            }
        }
    }

    @PluginMethod
    fun applyLayout(call: PluginCall) {
        controller.submitLayout(call.data, rejecting(call)) { call.resolve(JSObject.fromJSONObject(it)) }
    }

    @PluginMethod
    fun applyScrollOffsets(call: PluginCall) {
        controller.submitScrollOffsets(call.data, rejecting(call)) { call.resolve() }
    }

    @PluginMethod
    fun command(call: PluginCall) {
        controller.submitCommand(call.data, rejecting(call)) { call.resolve() }
    }

    @PluginMethod
    fun reset(call: PluginCall) {
        controller.submitReset(call.data, rejecting(call)) { call.resolve(JSObject.fromJSONObject(it)) }
    }

    private fun rejecting(call: PluginCall) = { code: String, message: String -> call.reject(message, code) }

    override fun handleOnResume() = controller.onHostResume()

    override fun handleOnPause() = controller.onHostPause()

    override fun handleOnDestroy() = controller.dispose()
}
