# @capacitor/native-islands

Native Islands lets a Capacitor app place an Android `View` or iOS `UIView` where a
custom HTML element appears in the page. The element's CSS controls its size,
position, stacking order, and rounded corners. The native view follows the document
when it scrolls, and web and native controls keep the same visual and touch order.

This package contains the composition runtime and Capacitor bridge. It does not
ship a component library, demo component, renderer engine, or Capacitor fork.

See [ARCHITECTURE.md](ARCHITECTURE.md) for the package boundaries and platform
differences.

## How it fits together

Native Islands separates component implementation from component use:

1. A component author defines a custom element, such as `<app-map>`, and implements
   the native view for each supported platform.
2. An application developer uses that element like ordinary HTML and controls its
   layout with CSS.
3. Native Islands places the registered native view at the element's location.
   Browsers without a native transport render the element's web implementation.

The WebView stays where the app put it. Native views go in a plane just under the page
and a plane just over it. On iOS, both planes are inside the WebView. On Android, they
are the WebView's siblings, so its parent must stack its children, as `FrameLayout` and
`CoordinatorLayout` do.

A component plugin can package the web definition and its native implementations. In
that case, an application developer installs the component plugin and does not need
to register the native view or understand the Native Islands bridge.

## Install

Install this package directly only when your application or component plugin defines
its own native components:

```sh
npm install @capacitor/native-islands
npx cap sync
```

No Native Islands block is required in `capacitor.config`.

When using a component plugin that already includes Native Islands, follow that
plugin's installation instructions instead. The application should not install or
configure Native Islands separately unless the component plugin says otherwise.

## Use a component in an application

After installing a component plugin, use its custom element in normal markup. The
plugin documents its available attributes, properties, and events.

```html
<app-map
  latitude="41.1579"
  longitude="-8.6291"
  style="display:block;height:280px;border-radius:24px;z-index:2"
></app-map>
```

CSS controls the element's layout and stacking just as it would for a web element.
Changing a documented attribute updates the native component. Native component
events arrive as ordinary DOM events.

## Define the custom element

This section and the native registration section are for component authors. An
application developer using an existing component plugin can use the element and
skip both sections.

Call `defineNativeIsland` once from browser entry-point code, such as `src/main.ts`:

```ts
import { defineNativeIsland } from '@capacitor/native-islands';

defineNativeIsland({
  tagName: 'app-map',
  nativeComponent: 'app.map',
  isInteractive: true,
  observedAttributes: ['latitude', 'longitude'],
  getProperties: (element) => ({
    latitude: Number(element.getAttribute('latitude')),
    longitude: Number(element.getAttribute('longitude')),
  }),
  renderFallback: (element) => {
    const latitude = Number(element.getAttribute('latitude'));
    const longitude = Number(element.getAttribute('longitude'));
    const link = document.createElement('a');
    link.href = `https://www.openstreetmap.org/?mlat=${latitude}&mlon=${longitude}`;
    link.textContent = 'Open location in a web map';
    element.replaceChildren(link);
  },
  events: {
    cameraChanged: 'camerachanged',
  },
});
```

In this definition:

- `tagName` is the HTML tag used by the application.
- `nativeComponent` is the name registered by the Android and iOS code.
- `getProperties` converts HTML attributes and styles into values for the native
  component.
- `renderFallback` renders usable content in a normal browser and supplies hidden
  accessibility semantics when accessibility is web-owned.
- `events` maps events emitted by the native component to DOM event names. Here,
  native `cameraChanged` becomes the `camerachanged` DOM event.

The runtime sends `create` the first time an element can be shown and `update` when
observed attributes change. Attribute changes in the same task are coalesced into one
update. Those are the only component commands. A rejected native command emits the
bubbling, composed `nativeislanderror` event and never substitutes web pixels.

Components that draw asynchronously after `create` can pass `firstFrame` in their
definition so the browser fallback stays visible until the native component emits its
first-frame event.

Component plugins can also list resolved CSS properties in `observedStyles`.
Changes caused by inline styles, classes, inherited custom properties, stylesheets,
or common system appearance preferences are coalesced into `update`. Read those
values with `getComputedStyle(element)` inside `getProperties`.

Observed attributes also expose reflected string properties when the name does not
collide with a built-in element property. Assigning `element.label = value` therefore
reaches the same attribute contract. `null` and `undefined` remove the attribute, and
`getProperties` converts numbers, booleans, and structured values.

DOM reparenting in the same task preserves the native identity and does not
send `create` again. An element rendered before its consuming plugin's native side
is ready uses its browser implementation, then activates once when the plugin initializes.

`renderFallback` is required. It must replace or update its complete output every
time it runs so repeated calls do not duplicate content. Avoid closing over the
custom-element instance. The runtime calls it on browser mount, after browser-side
attribute changes, and for web-owned accessibility.

Accessibility is web-owned by default. While native composition is active, the
runtime calls `renderFallback` with a visually hidden semantic container and hides
the native subtree from accessibility. If a component instead registers its native
factory with native accessibility, set `accessibility: 'native'` in the web
definition too. The web and native registrations must agree so only one
representation is exposed to assistive technologies.

Use lowercase kebab-case for custom-element tags, HTML attributes, and DOM event
names. Convert attributes to camelCase only in the JavaScript/native property object.
Native registry names use a stable dotted namespace such as `app.map`.

## Register the native component

The web definition uses `nativeComponent: 'app.map'` to request a native view.
Register a factory with that exact name on each supported platform. A factory is the
function that creates the platform's `NativeIsland` implementation.

Register it once during app or plugin startup, before an `<app-map>` element connects
to the document.

### iOS

Register from a Capacitor plugin's `load()` method or during app startup:

```swift
import IONNativeIslandsLib

NativeIslandsRegistry.register(componentName: "app.map") {
    AppMapIsland()
}
```

`AppMapIsland` implements `NativeIsland` and provides the `UIView` displayed by the
custom element. See the
[iOS runtime guide](https://github.com/ionic-team/ion-ios-native-islands#register-a-native-component)
for a complete component implementation.

### Android

Register from a Capacitor plugin's `load()` method or during app startup:

```kotlin
import io.ionic.libs.ionnativeislandslib.NativeIslandsRegistry

NativeIslandsRegistry.register(componentName = "app.map") { context, _ ->
    AppMapIsland(context)
}
```

`AppMapIsland` implements `NativeIsland` and provides the Android `View`. Native
Islands supplies the `Context` when it creates the component. See the
[Android runtime guide](https://github.com/ionic-team/ion-android-native-islands#register-a-native-component)
for a complete component implementation.

The controller calls `create(properties)` when the native view mounts and
`update(properties)` when an observed attribute or style changes. Each component
instance corresponds to one web mount instance and is recreated if the element
remounts as a new instance.

## Web layers and z-index

Native Islands follows the browser's stacking contexts and `z-index`. Application
authors use ordinary HTML and CSS without declaring layers or calling a stacking API.

The runtime automatically recognizes bounded elements whose computed background
fully covers their border box. It compares those surfaces with each island in the
browser's real paint order and sends only the intersections that need native visual
or touch cutouts.

```html
<div style="position:relative;height:300px">
  <div aria-hidden="true" style="position:absolute;inset:0;z-index:1;background:#eef2f7"></div>
  <app-map style="position:absolute;inset:20px;z-index:2"></app-map>
  <button style="position:absolute;right:36px;bottom:36px;z-index:3">Recenter</button>
</div>
```

For an advanced component integration, `data-native-islands-opaque-surface` can
confirm that a bounded surface the browser cannot classify, such as a fully opaque
image, is safe to treat as opaque. It does not change paint order. Ordinary app
screens should not need it. When a composition cannot be represented safely, the
affected native component becomes inactive, receives `data-native-islands-inactive`,
and renders its browser implementation instead.

Web paint above an island always covers it. While covering layers can be cut as boxes,
the island sits above the WebView and native cuts each covering layer along its own
scroll path and sticky offset. When translucent or animating web paint covers an
island, the island moves below the WebView when lower web knockouts stay aligned, or
uses a native backdrop tint over the island when it remains above the WebView.
Overlapping rounded underlays use an alpha-mask union so their shared region remains
transparent.

Outer box shadows, outlines, and translucent empty `::before` or `::after` fills,
such as a press halo, are not cut out. An island above the WebView draws over them.

Component plugins set `requiresUnobscuredSurface: true` for protected system
surfaces, which always sit above the WebView. A component that implements
rectangular native clipping also sets `supportsProtectedSurfaceClip: true`. Native
Islands clips header, sidebar, and other edge overlaps, and hides the surface while
an unclippable or moving cover remains. The platform decides whether a partly
covered surface accepts taps.

## Rounded corners

CSS `border-radius` on the custom element is detected automatically per corner, sent
to native, and used for both clipping and touch routing. Component users do not need a
separate radius property, and no radius is required for a rectangular element.
An elliptical corner is drawn as the largest circular corner that fits inside it.

## Scrolling and touch

Document scrolling is observed and applied natively. Island document coordinates
cross the bridge only after real layout changes.

Independent scroll ancestors are modeled, including nested containers and the inner
scroller used by standard Ionic `ion-content`. An ancestor counts when it has scroll
range and `overflow` is `auto`, `scroll`, or `hidden`. `overflow: clip` is excluded
because CSS makes it unscrollable.

iOS observes matched native child scroll views. Android uses ordinary browser
scrolling and sends one offset sample per frame ordered by layout generation, applied
on the Android main thread without reparenting or synthetic scroll range. Vertical,
horizontal, sibling, and nested scrollers are supported while the native view stays
mounted.

On slow Android devices, a fast fling in an inner scroll container can leave an island
a few frames behind the page. A protected surface, such as the system location button,
can also be missing for one frame as it comes back fully into view from under other web
content.

Fixed and sticky islands, and fixed web controls, participate in the same paint-order
plan. The page's transforms on an island and its ancestors are drawn natively as one
2D matrix: translations, scales (uneven, flipped, CSS `zoom`), turns, skews and CSS
motion paths, on or above a scroll container, at rest or animated. The host lays the island out at its own
size and draws it through that matrix, corners included. A 3D transform is drawn as the
page flattens it, seen straight on, without perspective. Layout transitions and ancestor
opacity fades are followed. Ancestors that clip part of an island (`overflow`, paint
containment, `clip-path: inset()`, `circle()` or `ellipse()`) clip the native view too.

Filters, backdrop filters, blending, masks and other `clip-path` shapes are not
replayed: the native view is drawn without them rather than not at all. An island under
an open modal `<dialog>` stays native, dimmed by the dialog's backdrop.

Every island the page shows is drawn natively, as closely as native can, so an island
never swaps between native and web as the page changes. Where the page cannot be
matched exactly, the island stays native and the nearest result is drawn: web paint
over it that native cannot cut to its shape is cut by its box. An island renders its web
fallback, marked `data-native-islands-inactive`, only when native cannot draw it at all
(native refuses its layout, or its geometry is out of range), and until native first
shows it.

An island native draws differently from the page carries
`data-native-islands-approximated`, listing what it leaves out or draws approximately:

| Code                 | What native draws                                                                                                                                   |
| -------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| `effects`            | The island without a filter, backdrop filter, blend mode or mask on it or above it.                                                                 |
| `clip-shape`         | The island without an ancestor's `clip-path` other than an inset, circle or ellipse; an ellipse clips as the rounded box its smaller radius rounds. |
| `elliptical-corners` | Elliptical corners as the circular corners they hold.                                                                                               |
| `perspective`        | A 3D transform in perspective, flattened.                                                                                                           |
| `box-cut`            | Web paint over the island native cannot cut to its shape or follow, cut by its box.                                                                 |
| `unfollowed-sticky`  | A sticky box native cannot follow, placed where it is at each plan.                                                                                 |

Inspect the attribute in the browser's developer tools.

Set `isInteractive: true` when the native component owns gestures that begin in its
visible region. A composed web surface above it keeps ownership of touches in its
overlap. Touch ownership does not change during a gesture. `pointer-events: none` or
an `inert` composed ancestor prevents a new native gesture from starting.

## Web framework compatibility

Native Islands components are standard custom elements. Use the normal custom-element
setup for the web framework in your app; Native Islands does not require a
framework-specific adapter. Define components only in browser code when using
server-side rendering.

Hot module replacement keeps native views: an element the framework keeps after an edit
updates its native view in place. Key list items by something stable, such as an id. A
key made from a value that changes, such as a label, makes the framework create a new
element, and Native Islands creates a new native view for it.

Open shadow roots and slotted islands are supported. A component that owns a closed
shadow root must expose an overlapping opaque surface through its host, because the
browser does not let Native Islands inspect the closed tree.

## API reference

The root package exports `defineNativeIsland`, `synchronizeNativeIslands`, `holdNativeIslands`,
`hostedIslands` and `takeHostedChanges`, with the `DefineNativeIslandOptions` and
`HostedIsland` types.

### `defineNativeIsland(options)`

```ts
function defineNativeIsland(options: DefineNativeIslandOptions): CustomElementConstructor;
```

Defines the custom element named by `options.tagName` and returns its constructor.
Call it once during browser startup, before the element is used in the document.

Calling it again with the same tag, native component, and structural options refreshes
`getProperties` and `renderFallback`, then returns the existing constructor. Existing
elements use the refreshed handlers on their next ordinary update or fallback render.
It throws when structural options change after registration, when the tag is already
assigned to another native component, when another library already defined the custom
element, or when the required names are invalid.

### `DefineNativeIslandOptions`

```ts
interface DefineNativeIslandOptions {
  tagName: `${string}-${string}`;
  nativeComponent: string;
  isInteractive?: boolean;
  accessibility?: 'web' | 'native';
  requiresUnobscuredSurface?: boolean;
  supportsProtectedSurfaceClip?: boolean;
  observedAttributes?: readonly string[];
  observedStyles?: readonly string[];
  preserveChildren?: boolean;
  hostsChildren?: boolean;
  firstFrame?: { event: string; timeoutMs?: number; startWhen?: (element: HTMLElement) => boolean };
  getProperties?: (element: HTMLElement, context?: { command: 'create' | 'update' }) => Record<string, unknown>;
  renderFallback: (element: HTMLElement) => void;
  events?: Readonly<Record<string, string>>;
}
```

| Option                         | Required | Default           | Purpose                                                                                                                    |
| ------------------------------ | -------- | ----------------- | -------------------------------------------------------------------------------------------------------------------------- |
| `tagName`                      | Yes      |                   | Custom-element tag used in HTML. It must contain a hyphen.                                                                 |
| `nativeComponent`              | Yes      |                   | Exact name registered by the iOS and Android factories.                                                                    |
| `renderFallback`               | Yes      |                   | Renders the browser implementation and optional web-owned accessibility semantics. It must be safe to call more than once. |
| `isInteractive`                | No       | `false`           | Lets the native view own gestures that begin in its visible region.                                                        |
| `accessibility`                | No       | `'web'`           | Chooses whether hidden web semantics or the native view owns accessibility. It must match the native registration.         |
| `requiresUnobscuredSurface`    | No       | `false`           | Marks a protected system surface.                                                                                          |
| `supportsProtectedSurfaceClip` | No       | `false`           | Declares that the Android component clips its protected surface to a rectangle.                                            |
| `observedAttributes`           | No       | `[]`              | Attribute names whose changes trigger a coalesced native `update`.                                                         |
| `observedStyles`               | No       | `[]`              | Computed CSS property names whose changes trigger a coalesced native `update`.                                             |
| `preserveChildren`             | No       | `false`           | Keeps author-provided child elements mounted.                                                                              |
| `hostsChildren`                | No       | `false`           | Makes the islands directly inside this one part of its native view, as a native list's cells. Implies `preserveChildren`.  |
| `firstFrame`                   | No       | None              | Keeps the browser implementation showing until the named native event fires, or `timeoutMs` passes.                        |
| `getProperties`                | No       | No properties     | Converts current element state into JSON-compatible properties for native `create` and `update` calls.                     |
| `events`                       | No       | No event mappings | Maps native event names to bubbling, composed DOM `CustomEvent` names.                                                     |

### `synchronizeNativeIslands()`

```ts
function synchronizeNativeIslands(): Promise<void>;
```

Plans every island against the page as it is now and resolves once native has applied
that plan. With no native, as in a browser, it resolves at once. Await it before showing a
page whose islands must already be in place, such as at the end of a transition.

### `holdNativeIslands()`

```ts
function holdNativeIslands(): () => Promise<void>;
```

Stops planning islands until the returned function is called, then plans once with
every change made meanwhile; the promise the release returns resolves once native has
applied that plan, or at once with no native. Use it while nothing of the page is seen, such as while a
native transition covers the page with a still: a page that builds itself in several
steps then costs one plan instead of one per step. Holds nest; calling a release more
than once has no further effect, and a hold never released ends after one second.

```ts
const release = holdNativeIslands();
await openPage();
await release(); // the page's islands are in place
showPage();
```

### `hostedIslands(host)` and `takeHostedChanges(host)`

```ts
function hostedIslands(host: Element): HostedIsland[];
function takeHostedChanges(host: Element): ReadonlySet<Element> | 'all';
```

For an island defined with `hostsChildren`. `hostedIslands` lists the islands directly
inside it, in order, with each one's component and properties. `takeHostedChanges` names
the children that changed, came or went since it last asked (`'all'` when it cannot
tell), so a host of many children redoes only those.

`@capacitor/native-islands/internal` is reserved for bridge packages that initialize
the same runtime with another transport. Separately bundled consuming plugins share
one page-wide runtime and registry, so application authors do not coordinate them.
Application code should not import the internal entry.

## License

MIT
