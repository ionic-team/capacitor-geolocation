# Architecture

Native Islands has four parts:

1. A custom element renders in browsers, reads CSS and attributes, and emits DOM events.
2. The web runtime measures layout and paint order, then produces a platform-neutral
   composition plan.
3. A Capacitor or Cordova transport carries that plan through the platform's plugin
   bridge and direct WebView message channels where available.
4. The Android and iOS runtimes host component views, route input, and apply the plan.

Component plugins register the native factory and define the matching custom element.
Application code uses the element and ordinary CSS. Native Islands does not include a
component library or require a framework-specific adapter.

## Web runtime

- `define-island.ts` defines the custom element; `island-presentation.ts` keeps its web
  and accessibility faces; `island-lifecycle.ts` tracks each island's native view.
- `runtime.ts` picks the transport and wires the pieces. `native-session.ts` owns one
  native reset over the transport: it stamps and sends layouts and scroll offsets, repairs a
  refused sample, and reports what native answers to `SessionReports`, the one port a
  session (or a test standing in for native) talks to. `native-events.ts` routes events;
  `document-watcher.ts` finds islands. `capacitor-transport.ts` and `internal-runtime.ts`
  carry the bridge.
- `stacking.ts` (`StackingService`) is the runtime's one seam to stacking: it registers
  islands and layers, takes the transport's configuration, begins each native session
  (handing back its `SessionReports`), decides when to plan, and sends each plan. It owns
  three parts, which see narrow inputs, never the service itself:
  - when: `frame-loop.ts` (the display clock, whether a plan is asked for, and how long
    frames are looked at), `page-watch.ts` (what changed), and `running-effects.ts` (the
    animations a plan reads, and motion held to start with the plan that carries it);
  - what: `scene-planner.ts` (`ScenePlanner`), which takes one plan's inputs and returns
    the layout with what it found (covered islands, where islands go below the WebView,
    a curtain, whether to follow every frame);
  - to native: `native-link.ts` (`NativeLink`), the session's state and what native has
    acknowledged. It sends each plan once and in order (retirements, paint fences, motion
    starts), knows what native holds and shows, and tells the planner so. Inside it,
    `layout-refusals.ts`, `scroll-offsets.ts` and `island-status.ts` keep the
    refusals, the inner scroll offsets, and which web fallbacks show and what native approximates.
- The planner owns its motion (`motion.ts`, `motion-plan.ts`) and the page's paint
  (`runtime-paint.ts`: the holes a plan wants, written with what each element had so it
  can be given back). It reads layers (`layers.ts`), places islands on planes
  (`planes.ts`) and writes the payload (`layout-writer.ts`, `regions.ts`). Reads are
  cached for one plan (`style-reads.ts`, `scene-reads.ts`, `scroll-geometry.ts`,
  `geometry.ts`); `stacking-order.ts` compares paint order.

## Composition

The WebView sits between native underlay and overlay hosts. Underlay components are
revealed through runtime-owned web knockout paths or alpha masks. Overlay components
use native cutouts for web paint above them, following each layer's scroll path and
sticky offset. Outer box shadows, outlines, and translucent empty pseudo-element fills
do not count as reaching an island, so an overlay draws over them. Semi-transparent
backdrops over an overlay island are sent as tint regions and drawn over the island's
native view. Protected surfaces are always overlays. Keeping the WebView as one layer
lets normal CSS stacking contexts and `z-index` remain the source of truth.

An opaque solid document canvas can be painted by the native host while the runtime
makes the body canvas transparent. This keeps an underlay visible when an inner
scroller returns to its starting position.

Host plane and coordinate space are independent. A viewport island may move to
the underlay plane when higher web paint needs transparency, provided its lower
web knockouts remain stationary relative to their paint. Lower native overlays
move with it when necessary to preserve CSS order. This does not add a scroll
refresh loop or change native component identity.

`composition-audit.ts` checks whether detached native pixels can reproduce the
element's current CSS. Unsupported transforms, effects, clipping, or shapes suspend
the affected native component. Partial opacity on an island or its ancestors is
applied as the native host's alpha. Native platforms never substitute web pixels.
Supported translate and opacity animations are evaluated natively on each display
frame, while other layout transitions are followed by planning each frame.

## Scrolling

Document scrolling stays native on both platforms and sends no bridge messages after
layout. Independent element scrollers use platform-specific implementations:

- iOS matches supported DOM scrollers to native child `UIScrollView` instances and
  observes their offsets.
- Android sends one offset vector per frame for supported inner scrollers, tagged with
  the layout generation, without waiting for acknowledgement. Carriers inject a WebView
  message channel that applies each sample on the main thread. Scroll gestures do not
  trigger new layout plans.
- Pointer events re-plan because `:hover` and `:active` can move or repaint layers
  without a mutation. Touch changes those states on a tap, so a touch pointer re-plans
  only at `pointerup`.

## Input

The layout plan contains separate visual cutouts and touch exclusions. At pointer-down,
the native container chooses the top eligible web or native target. That target owns
the complete gesture, except on Android where the container hands a single-finger drag
that began on an island to the WebView once it passes touch slop along a scrollable
axis unless the island calls `requestDisallowInterceptTouchEvent`.

## Bridge boundary

The bridge carries layout, inner-scroll offsets where needed, component `create` and
`update` commands, reset, and native events. Native code validates payload structure
and finite geometry before allocating views or invoking component code. Reset reports
platform capabilities (`heldOffsets` and `tintAlphaGradient` on Android; `paneColor`,
`motionStartsAtCommit` and `paintFence` on iOS; `motionScale` on both).

The transport abstraction is internal. It allows the same runtime to use Capacitor,
Cordova, or a feature plugin that carries Native Islands transitively. A single global
runtime prevents two consuming plugins from creating competing composition hosts.

## Public boundary

The root package exports `defineNativeIsland`, `synchronizeNativeIslands`,
`holdNativeIslands`, `hostedIslands` and `takeHostedChanges`, with their types;
`test/api-surface.test.mjs` holds that list. Component
commands remain `create` and `update`. Native component factories remain app or
component-plugin code. `renderFallback` supplies the browser implementation when
native composition is unavailable or suspended, and optional web-owned
accessibility semantics.

Protected Android surfaces can opt into rectangular clipping. Native placement
updates the surface clip from existing projected regions as scrolling moves it.
Unsupported overlap shapes still suspend that island.
