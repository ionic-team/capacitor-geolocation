# Architecture

Native Islands has four parts:

1. A custom element renders in browsers, reads CSS and attributes, and emits DOM events.
2. The web runtime measures layout and paint order, then produces a platform-neutral
   composition plan.
3. A Capacitor or Cordova transport carries that plan through the platform's plugin
   bridge and direct WebView message channels where available.
4. The Android and iOS runtimes host component views, route input, and apply the plan.

Component plugins register the native factory and define the matching custom element.
Application code uses the element and ordinary CSS. Native Islands does not include a
component library or require a framework-specific adapter.

## Composition

The WebView sits between native underlay and overlay hosts. Underlay components are
revealed through runtime-owned web knockout paths or alpha masks. Overlay components
use native cutouts for web paint above them, following each layer's scroll path and
sticky offset. Outer box shadows, outlines, and translucent empty pseudo-element fills
do not count as reaching an island, so an overlay draws over them. Semi-transparent
backdrops over an overlay island are sent as tint regions and drawn over the island's
native view. Protected surfaces are always overlays. Keeping the WebView as one layer
lets normal CSS stacking contexts and `z-index` remain the source of truth.

An opaque solid document canvas can be painted by the native host while the runtime
makes the body canvas transparent. This keeps an underlay visible when an inner
scroller returns to its starting position.

Host plane and coordinate space are independent. A viewport island may move to
the underlay plane when higher web paint needs transparency, provided its lower
web knockouts remain stationary relative to their paint. Lower native overlays
move with it when necessary to preserve CSS order. This does not add a scroll
refresh loop or change native component identity.

`composition-audit.ts` checks whether detached native pixels can reproduce the
element's current CSS. Unsupported transforms, effects, clipping, or shapes suspend
the affected native component. Partial opacity on an island or its ancestors is
applied as the native host's alpha. Native platforms never substitute web pixels.
Supported translate and opacity animations are evaluated natively on each display
frame, while other layout transitions are followed by planning each frame.

## Scrolling

Document scrolling stays native on both platforms and sends no bridge messages after
layout. Independent element scrollers use platform-specific implementations:

- iOS matches supported DOM scrollers to native child `UIScrollView` instances and
  observes their offsets.
- Android sends one offset vector per frame for supported inner scrollers, tagged with
  the layout generation, without waiting for acknowledgement. Carriers inject a WebView
  message channel that applies each sample on the main thread. Scroll gestures do not
  trigger new layout plans.
- Pointer events re-plan because `:hover` and `:active` can move or repaint layers
  without a mutation. Touch changes those states on a tap, so a touch pointer re-plans
  only at `pointerup`.

## Input

The layout plan contains separate visual cutouts and touch exclusions. At pointer-down,
the native container chooses the top eligible web or native target. That target owns
the complete gesture, except on Android where the container hands a single-finger drag
that began on an island to the WebView once it passes touch slop along a scrollable
axis unless the island calls `requestDisallowInterceptTouchEvent`.

## Bridge boundary

The bridge carries layout, inner-scroll offsets where needed, component `create` and
`update` commands, reset, and native events. Native code validates payload structure
and finite geometry before allocating views or invoking component code. Reset reports
platform capabilities (`heldOffsets` and `tintAlphaGradient` on Android, `paneColor`,
`motionStartsAtCommit`, and `paintFence` on iOS).

The transport abstraction is internal. It allows the same runtime to use Capacitor,
Cordova, or a feature plugin that carries Native Islands transitively. A single global
runtime prevents two consuming plugins from creating competing composition hosts.

## Public boundary

The root package exports only `defineNativeIsland` and its option type. Component
commands remain `create` and `update`. Native component factories remain app or
component-plugin code. `renderFallback` supplies the browser implementation when
native composition is unavailable or suspended, and optional web-owned
accessibility semantics.

Protected Android surfaces can opt into rectangular clipping. Native placement
updates the surface clip from existing projected regions as scrolling moves it.
Unsupported overlap shapes still suspend that island.
